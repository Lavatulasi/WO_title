#

This example design targeted on the Agilex-7 device is able to demonstrate a
hello world.


## Description

The following example design targeted on the Agilex-7 device enables Full ECC support for Nios® V/g core.
- The memory depth of OCM 409600
- With the default configuration and software sources, the application is
able to demonstrate a hello world.

## Project Details

- **Family**: Agilex 7
- **Quartus Version**: 24.3.0 Pro Edition
- **Development Kit**: Intel Agilex® 7 FPGA F-Series Development Kit
- **Device Part**: AGFB014R24B2E2V

